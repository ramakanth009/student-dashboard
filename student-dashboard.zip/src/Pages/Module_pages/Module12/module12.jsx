import React, { useState } from "react";
import { Box, Typography } from "@mui/material";
import { makeStyles } from "@mui/styles";
import ModuleDropdown from "../../../Elements/Moduledropdown/moduledropdown";
import ModuleSwitcher from "../../../Elements/Moduleselector/moduleselector";

const useStyles = makeStyles({
  moduleContainer: {
    padding: "24px",
    backgroundColor: "#f5f5f5",
    minHeight: "100vh",
  },
  header: {
    marginBottom: "24px",
  },
  moduleTitle: {
    color: "#333",
    fontWeight: "500!important",
    marginBottom: "24px!important",
  },
});

const Module12 = () => {
  const classes = useStyles();
  const [expandedIndex, setExpandedIndex] = useState(null);

  const sections = [
    {
      title: "1 Nodejs",
      status: "Completed",
      videoUrl: "https://example.com/video1",
      topics: [
        "Introduction to Nodejs and Installation",
        "Asynchronous and Non blocking Nature",
        "Folder Structure",
        "Nodejs Modules",
      ],
    },
    {
      title: "2 Nodejs",
      status: "In Progress",
      videoUrl: "https://example.com/video2",
      topics: [
        "Modules vs Packages",
        "NPM(Node Package Manager)",
        "core modules and User Defined Modules",
        "Exports and Imports",
      ],
    },
    {
      title: "3 Nodejs",
      status: "To Do",
      videoUrl: "https://example.com/video3",
      topics: [
        "File System- fs module",
        "Creation of Server and Printing Helloworld",
        "Rendering Already build frontend web application on this server",
      ],
    },
    {
      title: "4 Expressjs",
      status: "To Do",
      videoUrl: "https://example.com/video3",
      topics: [
        "Introduction to Expressjs",
        "MVC Architecture",
        "Router",
        "Middleware",
      ],
    },
    {
      title: "5 Expressjs",
      status: "To Do",
      videoUrl: "https://example.com/video3",
      topics: [
        "HTTP Methods",
        "Response and Request Object",
        "RestFull API Development",
        "Creating Dynamic Routes",
      ],
    },
    {
      title: "6 Expressjs",
      status: "To Do",
      videoUrl: "https://example.com/video3",
      topics: [
        "JSON Data",
        "Authorization (JWT Token majorly)",
        "Authentication",
        "API documentation",
      ],
    },
    {
      title: "7 Expressjs",
      status: "To Do",
      videoUrl: "https://example.com/video3",
      topics: [
        "Serialization and De-Serialization",
        "CORS Policy",
        "SOLID Principles",
        "Designe Patterns and atleast 1 pattern",
      ],
    },
  ];

  const handleAccordionChange = (index) => {
    setExpandedIndex(expandedIndex === index ? null : index);
  };

  return (
    <Box className={classes.moduleContainer}>
      <Box className={classes.header}>
        <ModuleSwitcher currentModule="/curriculam/module12" />
        <Typography variant="h4" className={classes.moduleTitle}>
          Intro to Node.js and Express.js
        </Typography>
      </Box>

      {sections.map((section, index) => (
        <ModuleDropdown
          key={index}
          index={index}
          title={section.title}
          status={section.status}
          topics={section.topics}
          videoUrl={section.videoUrl}
          expanded={expandedIndex === index}
          onChange={handleAccordionChange}
        />
      ))}
    </Box>
  );
};

export default Module12;
